<?php

namespace Woocampaign\WooIncludes\Event\Order;


class Order_Update extends \WP_Async_Request {

    /**
     * @var string
     */
    protected $action = 'order_update';

    /**
     * Handle
     *
     * Override this method to perform any actions required
     * during the async request.
     */
    protected function handle() {
        // Actions to perform


    }


}