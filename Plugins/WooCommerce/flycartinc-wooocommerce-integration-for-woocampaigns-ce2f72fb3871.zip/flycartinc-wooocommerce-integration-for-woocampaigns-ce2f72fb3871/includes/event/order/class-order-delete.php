<?php

namespace Woocampaign\WooIncludes\Event\Order;


class Order_Delete extends \WP_Async_Request {

    /**
     * @var string
     */
    protected $action = 'order_delete';

    /**
     * Handle
     *
     * Override this method to perform any actions required
     * during the async request.
     */
    protected function handle() {
        // Actions to perform


    }


}