<?php

namespace Woocampaign\WooIncludes\Event;

use Woocampaign\WooIncludes\Api\Request;


/**
 * Class Product
 */
class Product
{



    /**
     * @var
     */
    protected $uri;


    protected $product_create_request;

    protected $product_update_request;

    protected $product_delete_request;

    protected $product_restore_request;

    /**
     * Product constructor.
     * @param $uri
     */
    public function __construct($uri)
    {

        $this->uri = $uri;

    }


    public function create($meta_id, $post_id, $meta_key, $meta_value)
    {


        if (get_option('api_token_flag') && get_post_type($post_id) == 'product' && get_post($post_id)->post_title != "AUTO-DRAFT") {

            global $product_create_request;

            $this->product_create_request = $product_create_request;


            $this->product_create_request->push_to_queue( $post_id );

            $this->product_create_request->save()->dispatch();



        }


    }


    public function update($meta_id, $post_id, $meta_key, $meta_value)
    {

        if (get_option('api_token_flag') && $meta_key == '_edit_lock' && get_post_type($post_id) == 'product') {

            global $product_update_request;

            $this->product_update_request = $product_update_request;


            $this->product_update_request->push_to_queue( $post_id );
            $this->product_update_request->save()->dispatch();

        }

    }


    public function delete($post_id)
    {

        //TODO not working

        if (get_option('api_token_flag') && get_post_type($post_id) == 'product') {

            global $product_delete_request;

            $this->product_delete_request = $product_delete_request;

            $this->product_delete_request->push_to_queue( $post_id );
            $this->product_delete_request->save()->dispatch();


        }
    }

    public function restore($post_id)
    {

        //TODO not checked yet

        if (get_option('api_token_flag') && get_post_type($post_id) == 'product') {

            global $product_restore_request;

            $this->product_restore_request = $product_restore_request;

            $this->product_restore_request->push_to_queue( $post_id );
            $this->product_restore_request->save()->dispatch();



        }

    }




}