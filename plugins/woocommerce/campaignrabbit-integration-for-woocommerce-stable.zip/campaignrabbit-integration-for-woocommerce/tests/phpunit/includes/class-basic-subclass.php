<?php
/**
 * Unit Tests: Basic_Subclass class
 *
 * @package WordPress
 * @subpackage UnitTests
 * @since 4.7.0
 */

trigger_error( __FILE__ . ' is deprecated since version 5.0.0 with no alternative available.' );

/**
 * Class used to test accessing methods and properties.
 *
 * @since 4.0.0
 */
class Basic_Subclass extends Basic_Object {}
