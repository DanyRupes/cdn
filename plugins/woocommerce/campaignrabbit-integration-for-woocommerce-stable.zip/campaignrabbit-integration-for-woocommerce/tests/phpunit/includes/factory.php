<?php

require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-thing.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-post.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-bookmark.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-attachment.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-user.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-comment.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-blog.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-network.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-for-term.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-generator-sequence.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory-callback-after-create.php' );
require_once( dirname( __FILE__ ) . '/factory/class-wp-unittest-factory.php' );
